# Guia de publicação — Cofre Disney PWA

## O que você vai precisar
- Conta Google (qualquer Gmail)
- 15 minutos
- Um computador com Chrome

---

## PASSO 1 — Criar projeto Firebase (gratuito)

1. Acesse: https://console.firebase.google.com
2. Clique em **"Adicionar projeto"**
3. Nome do projeto: `cofre-disney` (ou qualquer nome)
4. Desative o Google Analytics (não precisa) → **Criar projeto**
5. Aguarde criar e clique em **Continuar**

---

## PASSO 2 — Ativar o Firestore (banco de dados)

1. No menu lateral, clique em **Firestore Database**
2. Clique em **Criar banco de dados**
3. Escolha **Modo de teste** (simples para começar)
4. Selecione região: `southamerica-east1` (São Paulo)
5. Clique em **Ativar**

---

## PASSO 3 — Pegar as credenciais do Firebase

1. No topo da página, clique na engrenagem ⚙️ → **Configurações do projeto**
2. Role até **"Seus aplicativos"**
3. Clique no ícone `</>` (Web)
4. Nome do app: `cofre-disney` → **Registrar app**
5. Você verá um bloco com `firebaseConfig` — pode ignorar, já está configurado.

---

## PASSO 4 — Configurar o app

✅ **As credenciais do Firebase já estão preenchidas no arquivo.**

A única coisa que você pode querer mudar é a senha de admin.
Abra o `public/index.html` no Bloco de Notas, encontre esta linha e troque:

```
const SENHA_ADMIN = "disney2029";  // ← mude para a senha que quiser
```

O restante já está configurado.

---

## PASSO 5 — Publicar com Firebase Hosting

### Instalar Node.js (se não tiver)
Baixe em: https://nodejs.org → instale a versão LTS

### No terminal (Prompt de Comando ou PowerShell):

```bash
# Instalar Firebase CLI
npm install -g firebase-tools

# Fazer login
firebase login

# Entrar na pasta do projeto
cd caminho/para/cofre-disney-v2

# Inicializar hosting
firebase init hosting
```

Quando perguntar:
- **"What do you want to use as your public directory?"** → digite `public`
- **"Configure as a single-page app?"** → `N`
- **"Set up automatic builds with GitHub?"** → `N`
- **"File public/index.html already exists. Overwrite?"** → `N`

```bash
# Publicar!
firebase deploy --only hosting
```

Ao final, você verá uma URL tipo:
`https://cofre-disney.web.app`

---

## PASSO 6 — Regras do Firestore (segurança)

No console Firebase → Firestore → **Regras**, cole:

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /cofre/sophia {
      allow read: if true;
      allow write: if true;
    }
  }
}
```

Clique em **Publicar**.

> Essas regras permitem qualquer pessoa ler e escrever no cofre da Sophia.
> Para o uso entre você e sua sobrinha isso é suficiente.
> O app já tem proteção por senha na interface admin.

---

## PASSO 7 — Instalar como app no celular

### No celular dela (Android ou iPhone):
1. Abra o Chrome (Android) ou Safari (iPhone)
2. Acesse a URL do seu app
3. Menu → "Adicionar à tela inicial"
4. O app vai aparecer como ícone normal na tela

### No seu celular:
Mesma coisa — você faz login com a senha admin.

---

## Personalizações fáceis

| O que mudar | Onde fica no index.html |
|---|---|
| Senha admin | `const SENHA_ADMIN = "..."` |
| Meta visível para ela | `const META = 12000` |
| Meta real base (custo da viagem) | `const META_REAL_BASE = 16510` |
| Inflação anual | `const INFLACAO = 0.05` |
| Valor da prova no ano base | `const PROVA_BASE = 100` |
| Cotação do euro | `const EUR_RATE = 6.20` |

---

## Custo total

| Serviço | Custo |
|---|---|
| Firebase Hosting | Grátis (até 10GB/mês) |
| Firestore | Grátis (até 50k leituras/dia) |
| Domínio `.web.app` | Grátis |
| **Total** | **R$ 0** |

---

## Suporte
Se travar em algum passo, me mostre a mensagem de erro e resolvemos.
